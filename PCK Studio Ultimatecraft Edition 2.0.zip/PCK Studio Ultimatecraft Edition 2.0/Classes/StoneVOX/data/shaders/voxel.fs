﻿#version 130                                                              

in vec4 _color;
out vec4 Color;  

void main()
{
    Color = _color;
}
