﻿#version 330
                                                                        
in vec3 ViewPos;

out vec3 PosOut;   

void main()
{
    PosOut = ViewPos;
}